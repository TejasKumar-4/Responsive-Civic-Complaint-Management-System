import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import StatusBadge from '@/components/StatusBadge';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { CheckCircle, MapPin, Calendar, Tag, Clipboard } from 'lucide-react';
import { format } from 'date-fns';
import { Navigate, Link } from 'react-router-dom';
import type { Database } from '@/integrations/supabase/types';

type Complaint = Database['public']['Tables']['complaints']['Row'];

export default function StaffDashboard() {
  const { user, isStaff, loading: authLoading } = useAuth();
  const qc = useQueryClient();

  const { data: assignments = [], isLoading } = useQuery({
    queryKey: ['staff-assignments', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('staff_assignments')
        .select('*')
        .eq('staff_id', user!.id)
        .order('assigned_at', { ascending: false });
      if (error) throw error;
      return data;
    },
    enabled: !!user && isStaff,
  });

  const complaintIds = assignments.map(a => a.complaint_id);

  const { data: complaints = [] } = useQuery({
    queryKey: ['staff-complaints', complaintIds],
    queryFn: async () => {
      if (complaintIds.length === 0) return [];
      const { data, error } = await supabase
        .from('complaints')
        .select('*')
        .in('id', complaintIds);
      if (error) throw error;
      return data as Complaint[];
    },
    enabled: complaintIds.length > 0,
  });

  const markCompleted = useMutation({
    mutationFn: async (complaintId: string) => {
      // Update assignment
      const { error: aErr } = await supabase
        .from('staff_assignments')
        .update({ completed_at: new Date().toISOString() })
        .eq('complaint_id', complaintId)
        .eq('staff_id', user!.id);
      if (aErr) throw aErr;

      // Update complaint status
      const { error: cErr } = await supabase
        .from('complaints')
        .update({ status: 'completed' as Database['public']['Enums']['complaint_status'] })
        .eq('id', complaintId);
      if (cErr) throw cErr;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['staff-assignments'] });
      qc.invalidateQueries({ queryKey: ['staff-complaints'] });
      qc.invalidateQueries({ queryKey: ['complaints'] });
      toast.success('Work marked as completed!');
    },
    onError: () => toast.error('Failed to update status'),
  });

  const categoryLabels: Record<string, string> = {
    pothole: 'Pothole', streetlight: 'Streetlight', garbage: 'Garbage',
    water_supply: 'Water Supply', drainage: 'Drainage', road_damage: 'Road Damage',
    electricity: 'Electricity', other: 'Other',
  };

  if (authLoading) return <div className="container py-12 text-center text-muted-foreground">Loading...</div>;
  if (!user || !isStaff) return <Navigate to="/login" replace />;

  const complaintMap = Object.fromEntries(complaints.map(c => [c.id, c]));

  const activeAssignments = assignments.filter(a => !a.completed_at);
  const completedAssignments = assignments.filter(a => a.completed_at);

  return (
    <div className="container py-6">
      <div className="mb-4 flex items-center gap-2">
        <Clipboard className="h-5 w-5 text-primary" />
        <h1 className="text-xl font-bold">My Assigned Tasks</h1>
      </div>

      {/* Stats */}
      <div className="mb-6 grid grid-cols-2 gap-3 sm:grid-cols-3">
        <div className="rounded-md border bg-card p-4 text-center">
          <p className="text-2xl font-bold">{assignments.length}</p>
          <p className="text-xs text-muted-foreground">Total Assigned</p>
        </div>
        <div className="rounded-md border bg-card p-4 text-center">
          <p className="text-2xl font-bold">{activeAssignments.length}</p>
          <p className="text-xs text-muted-foreground">Active</p>
        </div>
        <div className="rounded-md border bg-card p-4 text-center">
          <p className="text-2xl font-bold">{completedAssignments.length}</p>
          <p className="text-xs text-muted-foreground">Completed</p>
        </div>
      </div>

      {isLoading ? (
        <div className="py-8 text-center text-muted-foreground">Loading tasks...</div>
      ) : assignments.length === 0 ? (
        <div className="rounded-md border border-dashed bg-card p-8 text-center">
          <p className="text-muted-foreground">No tasks assigned to you yet.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {activeAssignments.length > 0 && (
            <>
              <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">Active Tasks</h2>
              {activeAssignments.map(a => {
                const c = complaintMap[a.complaint_id];
                if (!c) return null;
                return (
                  <div key={a.id} className="rounded-md border bg-card p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0 flex-1">
                        <div className="mb-1 flex items-center gap-2">
                          <span className="font-mono text-xs text-muted-foreground">{c.complaint_id}</span>
                          <StatusBadge status={c.status} />
                        </div>
                        <Link to={`/complaint/${c.id}`} className="font-semibold leading-snug hover:underline">{c.title}</Link>
                        <p className="mt-1 text-sm text-muted-foreground line-clamp-2">{c.description}</p>
                        <div className="mt-2 flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1"><MapPin className="h-3 w-3" />{c.location}</span>
                          <span className="flex items-center gap-1"><Tag className="h-3 w-3" />{categoryLabels[c.category]}</span>
                          <span className="flex items-center gap-1"><Calendar className="h-3 w-3" />Assigned {format(new Date(a.assigned_at), 'dd MMM yyyy')}</span>
                        </div>
                        {c.image_url && (
                          <img src={c.image_url} alt="" className="mt-2 max-h-32 rounded-md border object-cover" />
                        )}
                      </div>
                      <Button
                        onClick={() => markCompleted.mutate(a.complaint_id)}
                        disabled={markCompleted.isPending}
                        className="gap-1 shrink-0"
                      >
                        <CheckCircle className="h-4 w-4" />
                        Mark Completed
                      </Button>
                    </div>
                  </div>
                );
              })}
            </>
          )}

          {completedAssignments.length > 0 && (
            <>
              <h2 className="mt-4 text-sm font-semibold text-muted-foreground uppercase tracking-wide">Completed Tasks</h2>
              {completedAssignments.map(a => {
                const c = complaintMap[a.complaint_id];
                if (!c) return null;
                return (
                  <div key={a.id} className="rounded-md border bg-card p-4 opacity-70">
                    <div className="mb-1 flex items-center gap-2">
                      <span className="font-mono text-xs text-muted-foreground">{c.complaint_id}</span>
                      <StatusBadge status={c.status} />
                    </div>
                    <Link to={`/complaint/${c.id}`} className="font-semibold leading-snug hover:underline">{c.title}</Link>
                    <div className="mt-2 flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1"><MapPin className="h-3 w-3" />{c.location}</span>
                      <span className="flex items-center gap-1"><Calendar className="h-3 w-3" />Completed {a.completed_at ? format(new Date(a.completed_at), 'dd MMM yyyy') : ''}</span>
                    </div>
                  </div>
                );
              })}
            </>
          )}
        </div>
      )}
    </div>
  );
}
