import { useParams } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import StatusBadge from '@/components/StatusBadge';
import { Button } from '@/components/ui/button';
import { ThumbsUp, MapPin, Calendar, Tag, ArrowLeft } from 'lucide-react';
import { format } from 'date-fns';
import { Link } from 'react-router-dom';
import { toast } from 'sonner';

const categoryLabels: Record<string, string> = {
  pothole: 'Pothole', streetlight: 'Streetlight', garbage: 'Garbage',
  water_supply: 'Water Supply', drainage: 'Drainage', road_damage: 'Road Damage',
  electricity: 'Electricity', other: 'Other',
};

export default function ComplaintDetail() {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const qc = useQueryClient();

  const { data: complaint, isLoading } = useQuery({
    queryKey: ['complaint', id],
    queryFn: async () => {
      const { data, error } = await supabase.from('complaints').select('*').eq('id', id!).single();
      if (error) throw error;
      return data;
    },
    enabled: !!id,
  });

  const { data: hasVoted } = useQuery({
    queryKey: ['vote', id, user?.id],
    queryFn: async () => {
      if (!user) return false;
      const { data } = await supabase.from('complaint_votes').select('id').eq('complaint_id', id!).eq('user_id', user.id).maybeSingle();
      return !!data;
    },
    enabled: !!id && !!user,
  });

  const voteMutation = useMutation({
    mutationFn: async () => {
      if (!user || !id) throw new Error('Must be logged in');
      if (hasVoted) {
        await supabase.from('complaint_votes').delete().eq('complaint_id', id).eq('user_id', user.id);
      } else {
        await supabase.from('complaint_votes').insert({ complaint_id: id, user_id: user.id });
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['complaint', id] });
      qc.invalidateQueries({ queryKey: ['vote', id] });
      qc.invalidateQueries({ queryKey: ['complaints'] });
      toast.success(hasVoted ? 'Vote removed' : 'Upvoted!');
    },
    onError: () => toast.error('Failed to vote. You may have already voted.'),
  });

  if (isLoading) return <div className="container py-12 text-center text-muted-foreground">Loading...</div>;
  if (!complaint) return <div className="container py-12 text-center text-muted-foreground">Complaint not found.</div>;

  return (
    <div className="container max-w-3xl py-6">
      <Link to="/" className="mb-4 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" /> Back to complaints
      </Link>

      <div className="rounded-md border bg-card p-6">
        <div className="mb-3 flex items-center gap-2">
          <span className="font-mono text-xs text-muted-foreground">{complaint.complaint_id}</span>
          <StatusBadge status={complaint.status} />
        </div>
        <h1 className="text-xl font-bold">{complaint.title}</h1>

        <div className="mt-3 flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
          <span className="flex items-center gap-1"><MapPin className="h-4 w-4" />{complaint.location}</span>
          <span className="flex items-center gap-1"><Tag className="h-4 w-4" />{categoryLabels[complaint.category]}</span>
          <span className="flex items-center gap-1"><Calendar className="h-4 w-4" />{format(new Date(complaint.created_at), 'dd MMM yyyy, hh:mm a')}</span>
        </div>

        <p className="mt-4 whitespace-pre-wrap text-sm leading-relaxed">{complaint.description}</p>

        {complaint.image_url && (
          <img src={complaint.image_url} alt="Complaint" className="mt-4 max-h-80 rounded-md border object-cover" />
        )}

        {complaint.status === 'rejected' && complaint.rejection_reason && (
          <div className="mt-4 rounded-md border border-destructive/30 bg-destructive/5 p-3">
            <p className="text-sm font-medium text-destructive">Rejection Reason:</p>
            <p className="text-sm text-muted-foreground">{complaint.rejection_reason}</p>
          </div>
        )}

        <div className="mt-6 flex items-center gap-3 border-t pt-4">
          <Button
            variant={hasVoted ? 'default' : 'outline'}
            onClick={() => voteMutation.mutate()}
            disabled={!user || voteMutation.isPending}
            className="gap-2"
          >
            <ThumbsUp className="h-4 w-4" />
            {hasVoted ? 'Upvoted' : 'Upvote'} ({complaint.vote_count})
          </Button>
          {!user && <span className="text-xs text-muted-foreground">Login to vote</span>}
        </div>

        <p className="mt-3 text-xs text-muted-foreground">
          Last updated: {format(new Date(complaint.updated_at), 'dd MMM yyyy, hh:mm a')}
        </p>
      </div>
    </div>
  );
}
