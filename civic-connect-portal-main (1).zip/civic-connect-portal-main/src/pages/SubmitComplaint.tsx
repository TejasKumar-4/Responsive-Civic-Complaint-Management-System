import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import type { Database } from '@/integrations/supabase/types';

type Category = Database['public']['Enums']['complaint_category'];

export default function SubmitComplaint() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState('');
  const [category, setCategory] = useState<Category>('other');
  const [imageFile, setImageFile] = useState<File | null>(null);

  if (!user) {
    return (
      <div className="container py-12 text-center">
        <p className="text-muted-foreground">Please login to submit a complaint.</p>
        <Link to="/login"><Button className="mt-3">Login</Button></Link>
      </div>
    );
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !description.trim() || !location.trim()) {
      toast.error('Please fill all required fields');
      return;
    }
    setLoading(true);
    try {
      let image_url: string | null = null;
      if (imageFile) {
        const ext = imageFile.name.split('.').pop();
        const path = `${user.id}/${Date.now()}.${ext}`;
        const { error: upErr } = await supabase.storage.from('complaint-images').upload(path, imageFile);
        if (upErr) throw upErr;
        const { data: urlData } = supabase.storage.from('complaint-images').getPublicUrl(path);
        image_url = urlData.publicUrl;
      }

      const { error } = await supabase.from('complaints').insert({
        title: title.trim(),
        description: description.trim(),
        location: location.trim(),
        category,
        image_url,
        user_id: user.id,
      });
      if (error) throw error;

      toast.success('Complaint submitted successfully!');
      navigate('/');
    } catch (err: any) {
      toast.error(err.message || 'Failed to submit');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container max-w-2xl py-6">
      <Link to="/" className="mb-4 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" /> Back
      </Link>

      <div className="rounded-md border bg-card p-6">
        <h1 className="mb-4 text-xl font-bold">Submit a Complaint</h1>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="title">Title *</Label>
            <Input id="title" value={title} onChange={e => setTitle(e.target.value)} placeholder="e.g., Pothole on Main Road" maxLength={200} />
          </div>
          <div>
            <Label htmlFor="desc">Description *</Label>
            <Textarea id="desc" value={description} onChange={e => setDescription(e.target.value)} placeholder="Describe the issue in detail..." rows={4} maxLength={2000} />
          </div>
          <div>
            <Label htmlFor="loc">Location *</Label>
            <Input id="loc" value={location} onChange={e => setLocation(e.target.value)} placeholder="e.g., Sector 5, Near Bus Stand" maxLength={300} />
          </div>
          <div>
            <Label>Category</Label>
            <Select value={category} onValueChange={v => setCategory(v as Category)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="pothole">Pothole</SelectItem>
                <SelectItem value="streetlight">Streetlight</SelectItem>
                <SelectItem value="garbage">Garbage</SelectItem>
                <SelectItem value="water_supply">Water Supply</SelectItem>
                <SelectItem value="drainage">Drainage</SelectItem>
                <SelectItem value="road_damage">Road Damage</SelectItem>
                <SelectItem value="electricity">Electricity</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="img">Image (optional)</Label>
            <Input id="img" type="file" accept="image/*" onChange={e => setImageFile(e.target.files?.[0] || null)} />
          </div>
          <Button type="submit" disabled={loading} className="w-full">
            {loading ? 'Submitting...' : 'Submit Complaint'}
          </Button>
        </form>
      </div>
    </div>
  );
}
