import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import ComplaintCard from '@/components/ComplaintCard';
import { Search, Plus, FileText, Clock, CheckCircle, XCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import type { Database } from '@/integrations/supabase/types';

type Status = Database['public']['Enums']['complaint_status'];

export default function Index() {
  const { user } = useAuth();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<Status | 'all'>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');

  const { data: complaints = [], isLoading } = useQuery({
    queryKey: ['complaints', statusFilter, categoryFilter],
    queryFn: async () => {
      let q = supabase.from('complaints').select('*').order('vote_count', { ascending: false });
      if (statusFilter !== 'all') q = q.eq('status', statusFilter);
      if (categoryFilter !== 'all') q = q.eq('category', categoryFilter as Database['public']['Enums']['complaint_category']);
      const { data, error } = await q;
      if (error) throw error;
      return data;
    },
  });

  const filtered = complaints.filter(c =>
    search === '' ||
    c.title.toLowerCase().includes(search.toLowerCase()) ||
    c.description.toLowerCase().includes(search.toLowerCase()) ||
    c.location.toLowerCase().includes(search.toLowerCase()) ||
    c.complaint_id.toLowerCase().includes(search.toLowerCase())
  );

  const stats = {
    total: complaints.length,
    pending: complaints.filter(c => c.status === 'pending').length,
    resolved: complaints.filter(c => c.status === 'resolved').length,
    rejected: complaints.filter(c => c.status === 'rejected').length,
  };

  return (
    <div className="container py-6">
      {/* Stats */}
      <div className="mb-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <div className="rounded-md border bg-card p-4 text-center">
          <FileText className="mx-auto mb-1 h-5 w-5 text-primary" />
          <p className="text-2xl font-bold">{stats.total}</p>
          <p className="text-xs text-muted-foreground">Total</p>
        </div>
        <div className="rounded-md border bg-card p-4 text-center">
          <Clock className="mx-auto mb-1 h-5 w-5 text-warning" />
          <p className="text-2xl font-bold">{stats.pending}</p>
          <p className="text-xs text-muted-foreground">Pending</p>
        </div>
        <div className="rounded-md border bg-card p-4 text-center">
          <CheckCircle className="mx-auto mb-1 h-5 w-5 text-success" />
          <p className="text-2xl font-bold">{stats.resolved}</p>
          <p className="text-xs text-muted-foreground">Resolved</p>
        </div>
        <div className="rounded-md border bg-card p-4 text-center">
          <XCircle className="mx-auto mb-1 h-5 w-5 text-destructive" />
          <p className="text-2xl font-bold">{stats.rejected}</p>
          <p className="text-xs text-muted-foreground">Rejected</p>
        </div>
      </div>

      {/* Search + Filters */}
      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search complaints by title, ID, location..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={statusFilter} onValueChange={v => setStatusFilter(v as Status | 'all')}>
          <SelectTrigger className="w-[140px]"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="assigned">Assigned</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
            <SelectItem value="resolved">Resolved</SelectItem>
            <SelectItem value="rejected">Rejected</SelectItem>
          </SelectContent>
        </Select>
        <Select value={categoryFilter} onValueChange={setCategoryFilter}>
          <SelectTrigger className="w-[160px]"><SelectValue placeholder="Category" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            <SelectItem value="pothole">Pothole</SelectItem>
            <SelectItem value="streetlight">Streetlight</SelectItem>
            <SelectItem value="garbage">Garbage</SelectItem>
            <SelectItem value="water_supply">Water Supply</SelectItem>
            <SelectItem value="drainage">Drainage</SelectItem>
            <SelectItem value="road_damage">Road Damage</SelectItem>
            <SelectItem value="electricity">Electricity</SelectItem>
            <SelectItem value="other">Other</SelectItem>
          </SelectContent>
        </Select>
        {user && (
          <Link to="/submit">
            <Button className="gap-1">
              <Plus className="h-4 w-4" /> New Complaint
            </Button>
          </Link>
        )}
      </div>

      {search && filtered.length === 0 && !isLoading && (
        <div className="rounded-md border border-dashed bg-card p-8 text-center">
          <p className="text-muted-foreground">No complaints found for "{search}".</p>
          {user && (
            <Link to="/submit">
              <Button className="mt-3 gap-1"><Plus className="h-4 w-4" /> Submit New Complaint</Button>
            </Link>
          )}
        </div>
      )}

      {isLoading ? (
        <div className="py-12 text-center text-muted-foreground">Loading complaints...</div>
      ) : (
        <div className="space-y-3">
          {filtered.map(c => <ComplaintCard key={c.id} complaint={c} />)}
        </div>
      )}
    </div>
  );
}
