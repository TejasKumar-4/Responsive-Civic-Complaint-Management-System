import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import StatusBadge from '@/components/StatusBadge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { FileText, Clock, CheckCircle, XCircle, ThumbsUp, MapPin, Calendar, Tag, UserPlus, Users } from 'lucide-react';
import { format } from 'date-fns';
import { Navigate } from 'react-router-dom';
import type { Database } from '@/integrations/supabase/types';

type Status = Database['public']['Enums']['complaint_status'];
type Complaint = Database['public']['Tables']['complaints']['Row'];

export default function AdminDashboard() {
  const { user, isAdmin, loading: authLoading } = useAuth();
  const qc = useQueryClient();
  const [statusFilter, setStatusFilter] = useState<Status | 'all'>('all');
  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(null);
  const [rejectReason, setRejectReason] = useState('');
  const [showRejectDialog, setShowRejectDialog] = useState(false);
  const [showAssignDialog, setShowAssignDialog] = useState(false);
  const [selectedStaffId, setSelectedStaffId] = useState('');

  const { data: complaints = [], isLoading } = useQuery({
    queryKey: ['admin-complaints', statusFilter],
    queryFn: async () => {
      let q = supabase.from('complaints').select('*').order('vote_count', { ascending: false });
      if (statusFilter !== 'all') q = q.eq('status', statusFilter);
      const { data, error } = await q;
      if (error) throw error;
      return data;
    },
    enabled: isAdmin,
  });

  // Fetch staff members
  const { data: staffMembers = [] } = useQuery({
    queryKey: ['staff-members'],
    queryFn: async () => {
      const { data: roles, error } = await supabase
        .from('user_roles')
        .select('user_id')
        .eq('role', 'staff' as Database['public']['Enums']['app_role']);
      if (error) throw error;
      if (!roles.length) return [];
      const staffIds = roles.map(r => r.user_id);
      const { data: profiles, error: pErr } = await supabase
        .from('profiles')
        .select('*')
        .in('id', staffIds);
      if (pErr) throw pErr;
      return profiles || [];
    },
    enabled: isAdmin,
  });

  // Fetch assignments
  const { data: assignments = [] } = useQuery({
    queryKey: ['admin-assignments'],
    queryFn: async () => {
      const { data, error } = await supabase.from('staff_assignments').select('*');
      if (error) throw error;
      return data;
    },
    enabled: isAdmin,
  });

  const assignmentMap = Object.fromEntries(assignments.map(a => [a.complaint_id, a]));

  const updateStatus = useMutation({
    mutationFn: async ({ id, status, rejection_reason }: { id: string; status: Status; rejection_reason?: string }) => {
      const update: Record<string, unknown> = { status };
      if (rejection_reason) update.rejection_reason = rejection_reason;
      if (status !== 'rejected') update.rejection_reason = null;
      const { error } = await supabase.from('complaints').update(update).eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['admin-complaints'] });
      qc.invalidateQueries({ queryKey: ['complaints'] });
      toast.success('Status updated');
      setSelectedComplaint(null);
      setShowRejectDialog(false);
      setRejectReason('');
    },
    onError: () => toast.error('Failed to update status'),
  });

  const assignStaff = useMutation({
    mutationFn: async ({ complaintId, staffId }: { complaintId: string; staffId: string }) => {
      // Upsert assignment
      const { error: aErr } = await supabase
        .from('staff_assignments')
        .upsert({
          complaint_id: complaintId,
          staff_id: staffId,
          assigned_by: user!.id,
          completed_at: null,
        }, { onConflict: 'complaint_id' });
      if (aErr) throw aErr;

      // Update complaint status to assigned
      const { error: cErr } = await supabase
        .from('complaints')
        .update({ status: 'assigned' as Status })
        .eq('id', complaintId);
      if (cErr) throw cErr;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['admin-complaints'] });
      qc.invalidateQueries({ queryKey: ['admin-assignments'] });
      qc.invalidateQueries({ queryKey: ['complaints'] });
      toast.success('Staff assigned successfully');
      setShowAssignDialog(false);
      setSelectedComplaint(null);
      setSelectedStaffId('');
    },
    onError: () => toast.error('Failed to assign staff'),
  });

  if (authLoading) return <div className="container py-12 text-center text-muted-foreground">Loading...</div>;
  if (!user || !isAdmin) return <Navigate to="/login" replace />;

  const stats = {
    total: complaints.length,
    pending: complaints.filter(c => c.status === 'pending').length,
    assigned: complaints.filter(c => c.status === 'assigned').length,
    completed: complaints.filter(c => c.status === 'completed').length,
    resolved: complaints.filter(c => c.status === 'resolved').length,
    rejected: complaints.filter(c => c.status === 'rejected').length,
  };

  const handleReject = () => {
    if (!selectedComplaint || !rejectReason.trim()) {
      toast.error('Please provide a rejection reason');
      return;
    }
    updateStatus.mutate({ id: selectedComplaint.id, status: 'rejected', rejection_reason: rejectReason.trim() });
  };

  const handleAssign = () => {
    if (!selectedComplaint || !selectedStaffId) {
      toast.error('Please select a staff member');
      return;
    }
    assignStaff.mutate({ complaintId: selectedComplaint.id, staffId: selectedStaffId });
  };

  const categoryLabels: Record<string, string> = {
    pothole: 'Pothole', streetlight: 'Streetlight', garbage: 'Garbage',
    water_supply: 'Water Supply', drainage: 'Drainage', road_damage: 'Road Damage',
    electricity: 'Electricity', other: 'Other',
  };

  const getAssignedStaffName = (complaintId: string) => {
    const assignment = assignmentMap[complaintId];
    if (!assignment) return null;
    const staff = staffMembers.find(s => s.id === assignment.staff_id);
    return staff?.full_name || staff?.email || 'Unknown';
  };

  return (
    <div className="container py-6">
      <h1 className="mb-4 text-xl font-bold">Admin Dashboard</h1>

      {/* Stats */}
      <div className="mb-6 grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-6">
        <div className="rounded-md border bg-card p-4 text-center">
          <FileText className="mx-auto mb-1 h-5 w-5 text-primary" />
          <p className="text-2xl font-bold">{stats.total}</p>
          <p className="text-xs text-muted-foreground">Total</p>
        </div>
        <div className="rounded-md border bg-card p-4 text-center">
          <Clock className="mx-auto mb-1 h-5 w-5 text-warning" />
          <p className="text-2xl font-bold">{stats.pending}</p>
          <p className="text-xs text-muted-foreground">Pending</p>
        </div>
        <div className="rounded-md border bg-card p-4 text-center">
          <UserPlus className="mx-auto mb-1 h-5 w-5 text-primary" />
          <p className="text-2xl font-bold">{stats.assigned}</p>
          <p className="text-xs text-muted-foreground">Assigned</p>
        </div>
        <div className="rounded-md border bg-card p-4 text-center">
          <CheckCircle className="mx-auto mb-1 h-5 w-5 text-secondary" />
          <p className="text-2xl font-bold">{stats.completed}</p>
          <p className="text-xs text-muted-foreground">Completed</p>
        </div>
        <div className="rounded-md border bg-card p-4 text-center">
          <CheckCircle className="mx-auto mb-1 h-5 w-5 text-success" />
          <p className="text-2xl font-bold">{stats.resolved}</p>
          <p className="text-xs text-muted-foreground">Resolved</p>
        </div>
        <div className="rounded-md border bg-card p-4 text-center">
          <XCircle className="mx-auto mb-1 h-5 w-5 text-destructive" />
          <p className="text-2xl font-bold">{stats.rejected}</p>
          <p className="text-xs text-muted-foreground">Rejected</p>
        </div>
      </div>

      {/* Staff Overview */}
      <div className="mb-4 rounded-md border bg-card p-4">
        <div className="flex items-center gap-2 mb-2">
          <Users className="h-4 w-4 text-primary" />
          <h2 className="font-semibold text-sm">Staff Members ({staffMembers.length})</h2>
        </div>
        {staffMembers.length === 0 ? (
          <p className="text-xs text-muted-foreground">No staff members registered yet.</p>
        ) : (
          <div className="flex flex-wrap gap-2">
            {staffMembers.map(s => (
              <span key={s.id} className="rounded-md bg-accent px-2 py-1 text-xs">
                {s.full_name || s.email}
              </span>
            ))}
          </div>
        )}
      </div>

      {/* Filter */}
      <div className="mb-4">
        <Select value={statusFilter} onValueChange={v => setStatusFilter(v as Status | 'all')}>
          <SelectTrigger className="w-[160px]"><SelectValue placeholder="Filter status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="assigned">Assigned</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
            <SelectItem value="resolved">Resolved</SelectItem>
            <SelectItem value="rejected">Rejected</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Complaints Table */}
      {isLoading ? (
        <div className="py-8 text-center text-muted-foreground">Loading...</div>
      ) : (
        <div className="overflow-x-auto rounded-md border">
          <table className="w-full text-sm">
            <thead className="bg-muted">
              <tr>
                <th className="px-3 py-2 text-left font-medium">ID</th>
                <th className="px-3 py-2 text-left font-medium">Title</th>
                <th className="px-3 py-2 text-left font-medium">Category</th>
                <th className="px-3 py-2 text-left font-medium">Location</th>
                <th className="px-3 py-2 text-center font-medium">Votes</th>
                <th className="px-3 py-2 text-center font-medium">Status</th>
                <th className="px-3 py-2 text-left font-medium">Assigned To</th>
                <th className="px-3 py-2 text-left font-medium">Date</th>
                <th className="px-3 py-2 text-center font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {complaints.map(c => (
                <tr key={c.id} className="border-t hover:bg-accent/50 cursor-pointer" onClick={() => setSelectedComplaint(c)}>
                  <td className="px-3 py-2 font-mono text-xs">{c.complaint_id}</td>
                  <td className="px-3 py-2 max-w-[200px] truncate">{c.title}</td>
                  <td className="px-3 py-2">{categoryLabels[c.category]}</td>
                  <td className="px-3 py-2 max-w-[150px] truncate">{c.location}</td>
                  <td className="px-3 py-2 text-center font-bold">{c.vote_count}</td>
                  <td className="px-3 py-2 text-center"><StatusBadge status={c.status} /></td>
                  <td className="px-3 py-2 text-xs">{getAssignedStaffName(c.id) || '—'}</td>
                  <td className="px-3 py-2 text-xs">{format(new Date(c.created_at), 'dd MMM yyyy')}</td>
                  <td className="px-3 py-2 text-center">
                    <div className="flex justify-center gap-1" onClick={e => e.stopPropagation()}>
                      <Button size="sm" variant="outline" className="h-7 text-xs"
                        onClick={() => { setSelectedComplaint(c); setShowAssignDialog(true); }}
                        disabled={c.status === 'resolved' || c.status === 'rejected'}>
                        <UserPlus className="mr-1 h-3 w-3" />Assign
                      </Button>
                      {c.status === 'completed' && (
                        <Button size="sm" variant="outline" className="h-7 text-xs"
                          onClick={() => updateStatus.mutate({ id: c.id, status: 'resolved' })}>
                          Resolve
                        </Button>
                      )}
                      <Button size="sm" variant="outline" className="h-7 text-xs"
                        onClick={() => updateStatus.mutate({ id: c.id, status: 'pending' })}
                        disabled={c.status === 'pending'}>Pending</Button>
                      <Button size="sm" variant="outline" className="h-7 text-xs text-destructive"
                        onClick={() => { setSelectedComplaint(c); setShowRejectDialog(true); }}
                        disabled={c.status === 'rejected'}>Reject</Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Detail Dialog */}
      <Dialog open={!!selectedComplaint && !showRejectDialog && !showAssignDialog} onOpenChange={() => setSelectedComplaint(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{selectedComplaint?.title}</DialogTitle>
          </DialogHeader>
          {selectedComplaint && (
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs">{selectedComplaint.complaint_id}</span>
                <StatusBadge status={selectedComplaint.status} />
              </div>
              <p className="text-sm whitespace-pre-wrap">{selectedComplaint.description}</p>
              <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
                <span className="flex items-center gap-1"><MapPin className="h-3 w-3" />{selectedComplaint.location}</span>
                <span className="flex items-center gap-1"><Tag className="h-3 w-3" />{categoryLabels[selectedComplaint.category]}</span>
                <span className="flex items-center gap-1"><ThumbsUp className="h-3 w-3" />{selectedComplaint.vote_count} votes</span>
                <span className="flex items-center gap-1"><Calendar className="h-3 w-3" />{format(new Date(selectedComplaint.created_at), 'dd MMM yyyy')}</span>
              </div>
              {getAssignedStaffName(selectedComplaint.id) && (
                <div className="flex items-center gap-2 text-xs">
                  <UserPlus className="h-3 w-3 text-primary" />
                  <span>Assigned to: <strong>{getAssignedStaffName(selectedComplaint.id)}</strong></span>
                  {assignmentMap[selectedComplaint.id]?.completed_at && (
                    <span className="text-success font-medium">(Work Completed)</span>
                  )}
                </div>
              )}
              {selectedComplaint.image_url && (
                <img src={selectedComplaint.image_url} alt="" className="max-h-48 rounded-md border object-cover" />
              )}
              {selectedComplaint.rejection_reason && (
                <p className="text-xs text-destructive border-l-2 border-destructive pl-2">{selectedComplaint.rejection_reason}</p>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Reject Dialog */}
      <Dialog open={showRejectDialog} onOpenChange={v => { if (!v) { setShowRejectDialog(false); setRejectReason(''); } }}>
        <DialogContent>
          <DialogHeader><DialogTitle>Reject Complaint</DialogTitle></DialogHeader>
          <div>
            <Label>Rejection Reason *</Label>
            <Textarea value={rejectReason} onChange={e => setRejectReason(e.target.value)} placeholder="Provide reason for rejection..." rows={3} />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => { setShowRejectDialog(false); setRejectReason(''); }}>Cancel</Button>
            <Button variant="destructive" onClick={handleReject} disabled={updateStatus.isPending}>
              {updateStatus.isPending ? 'Rejecting...' : 'Reject Complaint'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Assign Staff Dialog */}
      <Dialog open={showAssignDialog} onOpenChange={v => { if (!v) { setShowAssignDialog(false); setSelectedStaffId(''); } }}>
        <DialogContent>
          <DialogHeader><DialogTitle>Assign Staff to Complaint</DialogTitle></DialogHeader>
          {selectedComplaint && (
            <div className="space-y-3">
              <p className="text-sm text-muted-foreground">
                Assigning staff to: <strong>{selectedComplaint.title}</strong> ({selectedComplaint.complaint_id})
              </p>
              <div>
                <Label>Select Staff Member *</Label>
                <Select value={selectedStaffId} onValueChange={setSelectedStaffId}>
                  <SelectTrigger><SelectValue placeholder="Choose a staff member..." /></SelectTrigger>
                  <SelectContent>
                    {staffMembers.map(s => (
                      <SelectItem key={s.id} value={s.id}>
                        {s.full_name || s.email}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              {staffMembers.length === 0 && (
                <p className="text-xs text-destructive">No staff members available. Register staff accounts first.</p>
              )}
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => { setShowAssignDialog(false); setSelectedStaffId(''); }}>Cancel</Button>
            <Button onClick={handleAssign} disabled={assignStaff.isPending || !selectedStaffId}>
              {assignStaff.isPending ? 'Assigning...' : 'Assign Staff'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
