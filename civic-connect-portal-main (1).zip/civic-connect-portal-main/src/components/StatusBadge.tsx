import type { Database } from '@/integrations/supabase/types';

type Status = Database['public']['Enums']['complaint_status'];

const statusClasses: Record<Status, string> = {
  pending: 'status-badge-pending',
  resolved: 'status-badge-resolved',
  rejected: 'status-badge-rejected',
  assigned: 'status-badge-assigned',
  completed: 'status-badge-completed',
};

export default function StatusBadge({ status }: { status: Status }) {
  return <span className={statusClasses[status] || 'status-badge-pending'}>{status}</span>;
}
