import { Link } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Shield, LogOut, User, LayoutDashboard, Clipboard } from 'lucide-react';

export default function GovHeader() {
  const { user, isAdmin, isStaff, signOut } = useAuth();

  return (
    <header>
      <div className="gov-stripe" />
      <div className="gov-header">
        <div className="container flex items-center justify-between py-3">
          <Link to="/" className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full border-2 border-secondary bg-primary-foreground">
              <Shield className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h1 className="text-lg font-bold leading-tight tracking-tight">
                Public Grievance Portal
              </h1>
              <p className="text-xs opacity-80">
                Citizen Complaint Management System
              </p>
            </div>
          </Link>
          <nav className="flex items-center gap-2">
            <Link to="/">
              <Button variant="ghost" size="sm" className="text-primary-foreground hover:bg-primary-foreground/10">
                Complaints
              </Button>
            </Link>
            {user ? (
              <>
                {isStaff && (
                  <Link to="/staff">
                    <Button variant="ghost" size="sm" className="text-primary-foreground hover:bg-primary-foreground/10">
                      <Clipboard className="mr-1 h-4 w-4" />
                      My Tasks
                    </Button>
                  </Link>
                )}
                {isAdmin && (
                  <Link to="/admin">
                    <Button variant="ghost" size="sm" className="text-primary-foreground hover:bg-primary-foreground/10">
                      <LayoutDashboard className="mr-1 h-4 w-4" />
                      Admin
                    </Button>
                  </Link>
                )}
                <Button variant="ghost" size="sm" onClick={signOut} className="text-primary-foreground hover:bg-primary-foreground/10">
                  <LogOut className="mr-1 h-4 w-4" />
                  Logout
                </Button>
              </>
            ) : (
              <Link to="/login">
                <Button variant="ghost" size="sm" className="text-primary-foreground hover:bg-primary-foreground/10">
                  <User className="mr-1 h-4 w-4" />
                  Login
                </Button>
              </Link>
            )}
          </nav>
        </div>
      </div>
      <div className="gov-stripe" />
    </header>
  );
}
