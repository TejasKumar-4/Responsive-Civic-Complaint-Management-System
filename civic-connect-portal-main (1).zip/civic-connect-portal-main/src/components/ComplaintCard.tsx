import { Tables } from '@/integrations/supabase/types';
import StatusBadge from './StatusBadge';
import { ThumbsUp, MapPin, Calendar, Tag } from 'lucide-react';
import { format } from 'date-fns';
import { Link } from 'react-router-dom';

const categoryLabels: Record<string, string> = {
  pothole: 'Pothole',
  streetlight: 'Streetlight',
  garbage: 'Garbage',
  water_supply: 'Water Supply',
  drainage: 'Drainage',
  road_damage: 'Road Damage',
  electricity: 'Electricity',
  other: 'Other',
};

export default function ComplaintCard({ complaint }: { complaint: Tables<'complaints'> }) {
  return (
    <Link to={`/complaint/${complaint.id}`} className="block">
      <div className="rounded-md border bg-card p-4 transition-shadow hover:shadow-md">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0 flex-1">
            <div className="mb-1 flex items-center gap-2">
              <span className="text-xs font-mono text-muted-foreground">{complaint.complaint_id}</span>
              <StatusBadge status={complaint.status} />
            </div>
            <h3 className="font-semibold leading-snug truncate">{complaint.title}</h3>
            <p className="mt-1 text-sm text-muted-foreground line-clamp-2">{complaint.description}</p>
            <div className="mt-2 flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
              <span className="flex items-center gap-1"><MapPin className="h-3 w-3" />{complaint.location}</span>
              <span className="flex items-center gap-1"><Tag className="h-3 w-3" />{categoryLabels[complaint.category] || complaint.category}</span>
              <span className="flex items-center gap-1"><Calendar className="h-3 w-3" />{format(new Date(complaint.created_at), 'dd MMM yyyy')}</span>
            </div>
            {complaint.status === 'rejected' && complaint.rejection_reason && (
              <p className="mt-2 text-xs text-destructive border-l-2 border-destructive pl-2">
                Rejected: {complaint.rejection_reason}
              </p>
            )}
          </div>
          <div className="flex flex-col items-center gap-1 rounded-md bg-accent px-3 py-2">
            <ThumbsUp className="h-4 w-4 text-primary" />
            <span className="text-sm font-bold">{complaint.vote_count}</span>
          </div>
        </div>
      </div>
    </Link>
  );
}
