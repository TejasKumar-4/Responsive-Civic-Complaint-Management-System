export default function GovFooter() {
  return (
    <footer className="mt-auto">
      <div className="gov-stripe" />
      <div className="gov-header py-6">
        <div className="container text-center text-sm opacity-80">
          <p>© {new Date().getFullYear()} Public Grievance Portal — Citizen Complaint Management System</p>
          <p className="mt-1 text-xs opacity-60">All rights reserved. Designed for public service.</p>
        </div>
      </div>
    </footer>
  );
}
