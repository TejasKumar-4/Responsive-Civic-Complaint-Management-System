
-- Allow staff to update complaint status (for marking as completed)
CREATE POLICY "Staff can update assigned complaints"
  ON public.complaints FOR UPDATE
  TO authenticated
  USING (
    public.has_role(auth.uid(), 'staff') AND
    EXISTS (
      SELECT 1 FROM public.staff_assignments
      WHERE staff_assignments.complaint_id = complaints.id
      AND staff_assignments.staff_id = auth.uid()
    )
  );
