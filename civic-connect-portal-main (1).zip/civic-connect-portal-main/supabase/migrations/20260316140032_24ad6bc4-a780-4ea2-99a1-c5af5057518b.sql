
-- Add 'assigned' and 'completed' to complaint_status enum
ALTER TYPE public.complaint_status ADD VALUE IF NOT EXISTS 'assigned';
ALTER TYPE public.complaint_status ADD VALUE IF NOT EXISTS 'completed';
